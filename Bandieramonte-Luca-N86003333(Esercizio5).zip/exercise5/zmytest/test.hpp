
#ifndef MYTEST_HPP
#define MYTEST_HPP

#include "../matrix/matrix.hpp"
#include "../matrix/csr/matrixcsr.hpp"
#include "../matrix/vec/matrixvec.hpp"

#include "../zlasdtest/test.hpp"

/* ************************************************************************** */

void testMenu();

/* ************************************************************************** */

#endif

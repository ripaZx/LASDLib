
#ifndef MYTEST_HPP
#define MYTEST_HPP

#include "../binarytree/binarytree.hpp"
#include "../binarytree/lnk/binarytreelnk.hpp"
#include "../binarytree/vec/binarytreevec.hpp"

#include "../zlasdtest/test.hpp"

/* ************************************************************************** */

void testMenu();

/* ************************************************************************** */

#endif


void testFullExercise3() {
}


#ifndef EX1TEST_HPP
#define EX1TEST_HPP

/* ************************************************************************** */

void testSimpleExercise1();

void testFullExercise1();

/* ************************************************************************** */

#endif


void testFullExercise1() {
}

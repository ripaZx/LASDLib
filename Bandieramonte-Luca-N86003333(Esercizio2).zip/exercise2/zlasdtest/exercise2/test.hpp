
#ifndef EX2TEST_HPP
#define EX2TEST_HPP

/* ************************************************************************** */

void testSimpleExercise2();

void testFullExercise2();

/* ************************************************************************** */

#endif


#ifndef MYTEST_HPP
#define MYTEST_HPP

#include "../bst/bst.hpp"

#include "../zlasdtest/test.hpp"

/* ************************************************************************** */

void testMenu();

/* ************************************************************************** */

#endif


void testFullExercise3() {
}

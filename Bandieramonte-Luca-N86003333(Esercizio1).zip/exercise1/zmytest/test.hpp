
#ifndef MYTEST_HPP
#define MYTEST_HPP

#include "../list/list.hpp"
#include "../vector/vector.hpp"

#include "../zlasdtest/test.hpp"

/* ************************************************************************** */

void testMenu();

/* ************************************************************************** */

#endif
